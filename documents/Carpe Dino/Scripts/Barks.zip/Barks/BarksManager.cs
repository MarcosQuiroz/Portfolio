using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class BarksManager : MonoBehaviour
{
    [SerializeField] float timeBarkOnScreen = 5;
    [SerializeField] Image partnerExpression;
    [SerializeField] TMP_Text barkUI;

    [SerializeField] Sprite[] crowExpressions;
    [SerializeField] Sprite[] newtExpressions;
    [SerializeField] Sprite[] oskaExpressions;

    [SerializeField]
    private AudioClip[] DinoVoiceover;

    string Newt_B_000 = "How odd, the beetles don't usually attack like this!";
    string Newt_B_001 = "Oh wow, we're really doing this!";
    string Newt_B_002 = "You're quite strong, you know.";
    string Newt_B_003 = "This is a breeze with you by my side!";
    string Newt_B_004 = "I don't really like to take risks....";
    string Newt_B_005 = "Ah, I'm starting to get nervous!";
    string Newt_B_006 = "It's the end for me!";
    string Newt_B_007 = "I really need a hand over here!";
    string Newt_B_008 = "I'm going to black out!!";
    string Newt_B_009 = "Maybe this will help!";
    string Newt_B_010 = "Stay back, tiny terrors!";

    string Crow_B_000 = "Ew, what the heck? Why are the bugs acting up like this?!";
    string Crow_B_001 = "Not bad, four-legs.";
    string Crow_B_002 = "I didn't think you had it in ya!";
    string Crow_B_003 = "See? Told you I'd be fine on my own.";
    string Crow_B_004 = "Bit of a risk-taker, huh?";
    string Crow_B_005 = "This isn't funny anymore!";
    string Crow_B_006 = "Do I have to say please?!";
    string Crow_B_007 = "I'm still here, you know!!";
    string Crow_B_008 = "I knew I should have gone alone!";
    string Crow_B_009 = "Hey!! Turn up the volume!";
    string Crow_B_010 = "Come on, let's rock n' roll!!";

    string Oska_B_000 = "Ew, what the heck? Why are the bugs acting up like this?!";
    string Oska_B_001 = "Not bad, four-legs.";
    string Oska_B_002 = "I didn't think you had it in ya!";
    string Oska_B_003 = "See? Told you I'd be fine on my own.";
    string Oska_B_004 = "Bit of a risk-taker, huh?";
    string Oska_B_005 = "This isn't funny anymore!";
    string Oska_B_006 = "Do I have to say please?!";
    string Oska_B_007 = "I'm still here, you know!!";
    string Oska_B_008 = "I knew I should have gone alone!";
    string Oska_B_009 = "Hey!! shortcut is coming up, follow this directions: \n";
    string Oska_B_010 = "shortcut is coming up, follow this directions: \n";

    Dictionary<string, EDialogueCategory> NewtBarks = new Dictionary<string, EDialogueCategory>();
    Dictionary<string, EDialogueCategory> CrowBarks = new Dictionary<string, EDialogueCategory>();
    Dictionary<string, EDialogueCategory> OskaBarks = new Dictionary<string, EDialogueCategory>();

    PartnerCharacter partner;
    EnergyManager partnerEnergyManager;
    EDialogueCategory dialogueCategory = EDialogueCategory.BeginGame;
    bool partnerUsedAbility = false;

    bool hasBarkFirstRangeDisplayed = false;
    bool hasBarkSecondRangeDisplayed = false;
    bool hasBarkThirdRangeDisplayed = false;

    // Start is called before the first frame update
    void Start()
    {
        NewtBarks.Add(Newt_B_000, EDialogueCategory.BeginGame);
        NewtBarks.Add(Newt_B_001, EDialogueCategory.FirstRange);
        NewtBarks.Add(Newt_B_002, EDialogueCategory.FirstRange);
        NewtBarks.Add(Newt_B_003, EDialogueCategory.FirstRange);
        NewtBarks.Add(Newt_B_004, EDialogueCategory.SecondRange);
        NewtBarks.Add(Newt_B_005, EDialogueCategory.SecondRange);
        NewtBarks.Add(Newt_B_006, EDialogueCategory.ThirdRange);
        NewtBarks.Add(Newt_B_007, EDialogueCategory.ThirdRange);
        NewtBarks.Add(Newt_B_008, EDialogueCategory.ThirdRange);
        NewtBarks.Add(Newt_B_009, EDialogueCategory.Ability);
        NewtBarks.Add(Newt_B_010, EDialogueCategory.Ability);


        CrowBarks.Add(Crow_B_000, EDialogueCategory.BeginGame);
        CrowBarks.Add(Crow_B_001, EDialogueCategory.FirstRange);
        CrowBarks.Add(Crow_B_002, EDialogueCategory.FirstRange);
        CrowBarks.Add(Crow_B_003, EDialogueCategory.FirstRange);
        CrowBarks.Add(Crow_B_004, EDialogueCategory.SecondRange);
        CrowBarks.Add(Crow_B_005, EDialogueCategory.SecondRange);
        CrowBarks.Add(Crow_B_006, EDialogueCategory.ThirdRange);
        CrowBarks.Add(Crow_B_007, EDialogueCategory.ThirdRange);
        CrowBarks.Add(Crow_B_008, EDialogueCategory.ThirdRange);
        CrowBarks.Add(Crow_B_009, EDialogueCategory.Ability);
        CrowBarks.Add(Crow_B_010, EDialogueCategory.Ability);

        OskaBarks.Add(Oska_B_000, EDialogueCategory.BeginGame);
        OskaBarks.Add(Oska_B_001, EDialogueCategory.FirstRange);
        OskaBarks.Add(Oska_B_002, EDialogueCategory.FirstRange);
        OskaBarks.Add(Oska_B_003, EDialogueCategory.FirstRange);
        OskaBarks.Add(Oska_B_004, EDialogueCategory.SecondRange);
        OskaBarks.Add(Oska_B_005, EDialogueCategory.SecondRange);
        OskaBarks.Add(Oska_B_006, EDialogueCategory.ThirdRange);
        OskaBarks.Add(Oska_B_007, EDialogueCategory.ThirdRange);
        OskaBarks.Add(Oska_B_008, EDialogueCategory.ThirdRange);

        partner = FindObjectOfType<PartnerCharacter>();
        partnerEnergyManager = partner.GetCharacterEnergy().energyManager;

        StartCoroutine(PlayBark());
    }

    private void Update()
    {
        GetDialogueCategory();
    }

    void GetDialogueCategory()
    {
        float healthPercentage = ((float)partnerEnergyManager.currentEnergy / (float)partnerEnergyManager.maxEnergy) * 100f;

        if (healthPercentage <= 80 && !hasBarkFirstRangeDisplayed)
        {
            dialogueCategory = EDialogueCategory.FirstRange;
            hasBarkFirstRangeDisplayed = true;
            StartCoroutine(PlayBark());
        }
        else if (healthPercentage <= 50 && !hasBarkSecondRangeDisplayed)
        {
            dialogueCategory = EDialogueCategory.SecondRange;
            hasBarkSecondRangeDisplayed = true;
            StartCoroutine(PlayBark());

        }
        else if (healthPercentage <= 20 && !hasBarkThirdRangeDisplayed)
        {
            dialogueCategory = EDialogueCategory.ThirdRange;
            hasBarkThirdRangeDisplayed = true;
            StartCoroutine(PlayBark());

        }
    }

    string GetBark(Dictionary<string, EDialogueCategory> partnerBarkList)
    {
        List<string> matchingDialogueCategories = new List<string>();

        foreach (var dialogue in partnerBarkList)
        {
            if (dialogue.Value == dialogueCategory)
                matchingDialogueCategories.Add(dialogue.Key);
        }

        int randBarkNumber = Random.Range(0, matchingDialogueCategories.Count());

        string bark = matchingDialogueCategories[randBarkNumber];

        return bark;
    }

    IEnumerator PlayBark()
    {
        SoundManager.Instance.PlaySoundEffect(DinoVoiceover[(int)dialogueCategory].name);

        if (partner is Newt)
        {
            string currentBark = GetBark(NewtBarks);
            partnerExpression.sprite = newtExpressions[(int)dialogueCategory];
            barkUI.text = currentBark;
        }
        else if (partner is Crow)
        {
            string currentBark = GetBark(CrowBarks);
            partnerExpression.sprite = crowExpressions[(int)dialogueCategory];
            barkUI.text = currentBark;
        }
        else if(partner is Oska)
        {
            string currentBark = GetBark(OskaBarks);
            partnerExpression.sprite = oskaExpressions[(int)dialogueCategory];
            barkUI.text = currentBark;
        }

        partnerExpression.gameObject.SetActive(true);
        barkUI.transform.parent.gameObject.SetActive(true);

        yield return new WaitForSeconds(timeBarkOnScreen);

        while (partnerUsedAbility)
            yield return null;

        partnerExpression.gameObject.SetActive(false);
        barkUI.transform.parent.gameObject.SetActive(false);
    }

    public IEnumerator PlayAbilityBark()
    {
        partnerUsedAbility = true;

        SoundManager.Instance.PlaySoundEffect(DinoVoiceover[3].name);
        dialogueCategory = EDialogueCategory.Ability;

        if (partner is Newt)
        {
            string currentBark = GetBark(NewtBarks);
            partnerExpression.sprite = newtExpressions[3];
            barkUI.text = currentBark;
        }
        else if (partner is Crow)
        {
            string currentBark = GetBark(CrowBarks);
            partnerExpression.sprite = crowExpressions[3];
            barkUI.text = currentBark;
        }
        else if (partner is Oska)
        {
            string currentBark = GetBark(OskaBarks);
            partnerExpression.sprite = oskaExpressions[3];
            barkUI.text = currentBark;
        }

        partnerExpression.gameObject.SetActive(true);
        barkUI.transform.parent.gameObject.SetActive(true);

        yield return new WaitForSeconds(timeBarkOnScreen);

        partnerExpression.gameObject.SetActive(false);
        barkUI.transform.parent.gameObject.SetActive(false);

        partnerUsedAbility = false;
    }

    public void AddOrderOfExecutionToOskaAbilityBark(string codeText)
    {
        Oska_B_009 += codeText;
        Oska_B_010 += codeText;

        OskaBarks.Add(Oska_B_009, EDialogueCategory.Ability);
        OskaBarks.Add(Oska_B_010, EDialogueCategory.Ability);
    }
}

public enum EDialogueCategory
{
    BeginGame,
    FirstRange,
    SecondRange,
    ThirdRange,
    Ability
}
