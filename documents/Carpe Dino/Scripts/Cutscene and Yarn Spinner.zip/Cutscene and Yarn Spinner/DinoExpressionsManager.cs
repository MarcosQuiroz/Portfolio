using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Yarn.Unity;

public class DinoExpressionsManager : MonoBehaviour
{
    [SerializeField] Image DinoImageUI;
    [SerializeField] Sprite[] CrowExpressionsImages;
    [SerializeField] Sprite[] HeroExpressionsImages;
    [SerializeField] Sprite[] AnkyExpressionsImages;
    [SerializeField] Sprite[] VenusExpressionsImages;

    [SerializeField]
    private AudioClip[] CrowvoiceOver;

    [SerializeField]
    private AudioClip[] HerovoiceOver;

    [SerializeField]
    private AudioClip[] AnkyvoiceOver;

    [SerializeField]
    private AudioClip[] VenusvoiceOver;

    private DialogueRunner dialogueRunner;

    Vector3 positionOne = new Vector3(175, 197, 0);
    Vector3 positionTwo = new Vector3(960, 540, 0);

    Vector3 scaleOne = new Vector3(0.8f, 0.8f, 0.8f);
    Vector3 scaleTwo = Vector3.one;

    RectTransform dinoImageTransform;

    private void Awake()
    {
        dialogueRunner = FindObjectOfType<DialogueRunner>();
        dialogueRunner.AddFunction<string, int, bool>("Change_Dino_Expression", ChangeDinoExpression);

        dinoImageTransform = DinoImageUI.GetComponent<RectTransform>();
    }

    private bool ChangeDinoExpression(string dinoName, int expressionIndex)
    {
        expressionIndex -= 1;

        switch (dinoName)
        {
            case "Crow":
                dinoImageTransform.anchoredPosition = positionOne;
                dinoImageTransform.localScale = scaleOne;

                DinoImageUI.sprite = CrowExpressionsImages[expressionIndex];
                SoundManager.Instance.PlaySoundEffect(CrowvoiceOver[expressionIndex].name);
                break;
            case "Hero":
                dinoImageTransform.anchoredPosition = positionOne;
                dinoImageTransform.localScale = scaleOne;

                DinoImageUI.sprite = HeroExpressionsImages[expressionIndex];
                SoundManager.Instance.PlaySoundEffect(HerovoiceOver[expressionIndex].name);
                break;
            case "Anky":
                dinoImageTransform.anchoredPosition = positionOne;
                dinoImageTransform.localScale = scaleOne;

                DinoImageUI.sprite = AnkyExpressionsImages[expressionIndex];
                SoundManager.Instance.PlaySoundEffect(AnkyvoiceOver[expressionIndex].name);
                break;
            case "Venus":

                dinoImageTransform.anchoredPosition = positionTwo;
                dinoImageTransform.localScale = scaleTwo;

                if (!DinoImageUI.gameObject.activeSelf)
                    DinoImageUI.gameObject.SetActive(true);

                DinoImageUI.sprite = VenusExpressionsImages[expressionIndex];
                SoundManager.Instance.PlaySoundEffect(VenusvoiceOver[expressionIndex].name);
                break;
        }

        return true;
    }
}
