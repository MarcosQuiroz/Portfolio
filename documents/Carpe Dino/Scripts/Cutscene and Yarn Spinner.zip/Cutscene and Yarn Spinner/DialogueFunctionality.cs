using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Yarn.Unity;

#if UNITY_EDITOR
using UnityEditor;
#endif

public class DialogueFunctionality : MonoBehaviour
{
    private DialogueRunner dialogueRunner;
    private InMemoryVariableStorage variableStorage;

    [SerializeField] private Slider reputationBar;

    internal object reputation;

    [Space(25)]
    [SerializeField]
#if UNITY_EDITOR
    [ReadOnly]
#endif
    internal bool debugMode;

    private void Awake()
    {
        dialogueRunner = FindObjectOfType<DialogueRunner>();
        variableStorage = FindObjectOfType<InMemoryVariableStorage>();

        dialogueRunner.AddFunction<string, bool>("SetMapStage", SetMapStage);
        dialogueRunner.AddFunction<string, bool>("SetHeroDialogue", SetHeroDialogue);
        dialogueRunner.AddFunction<string, bool>("SetCrowDialogue", SetCrowDialogue);
        dialogueRunner.AddFunction<bool, bool>("SetActiveMinigame1_Button", SetActiveMinigame1_Button);
        dialogueRunner.AddFunction<bool, bool>("SetActiveVenus_Button", SetActiveVenus_Button);
        dialogueRunner.AddFunction<bool>("SetDialogueBasedOnPartner", SetDialogueBasedOnPartner);
        dialogueRunner.AddFunction<string, bool>("LoadScene", LoadScene);
        dialogueRunner.AddFunction<int, bool>("IntroCutsceneSetup", IntroCutsceneSetup);
        dialogueRunner.AddFunction<int, bool>("SetActiveConclusionWidgetIndex", SetActiveConclusionWidgetIndex);
        dialogueRunner.AddFunction<int, bool>("ModifyReputation", ModifyReputation);
        dialogueRunner.AddFunction<int, bool>("SetNonRomanceableOutcome", SetNonRomanceableOutcome);

        LoadReputation();
        SceneManager.sceneUnloaded += OnSceneUnloaded;
        debugMode = false;
        //LoadChanges();
    }

    private void LoadReputation()
    {
        switch (InGameData.Instance.DialogueType)
        {
            case EDialogueType.Hero_101:
                dialogueRunner.VariableStorage.TryGetValue("$HeroLove", out reputation);
                reputationBar.gameObject.SetActive(true);
                ChangeSliderValue();
                break;
            case EDialogueType.Crow_101:
                dialogueRunner.VariableStorage.TryGetValue("$CrowLove", out reputation);
                reputationBar.gameObject.SetActive(true);
                ChangeSliderValue();
                break;
        }
    }


    private void OnSceneUnloaded(Scene scene)
    {
        switch (InGameData.Instance.DialogueType)
        {
            case EDialogueType.Hero_101:
                InGameData.Instance.heroReputation = System.Convert.ToInt32(reputation);
                break;
            case EDialogueType.Crow_101:
                InGameData.Instance.crowReputation = System.Convert.ToInt32(reputation);
                break;
        }
    }

    private void ChangeSliderValue()
    { reputationBar.value = System.Convert.ToUInt32(reputation); }

    private bool LoadScene(string sceneName)
    {
        SceneManager.LoadSceneAsync(sceneName);
        return true;
    }
    private bool SetMapStage(string stage)
    {
        if (Enum.TryParse<EMapStage>(stage, out EMapStage mapStage))
        {
            InGameData.Instance.MapStage = mapStage;
            InGameData.Instance.MapStageName = stage;

            return true;
        }
        else
        {
            Debug.LogError("Invalid map name: " + stage);

            return false;
        }
    }

    private bool SetHeroDialogue(string dialogue)
    {
        if (Enum.TryParse<EDialogueType>(dialogue, out EDialogueType heroDialogue))
        {
            InGameData.Instance.HeroDialogue = heroDialogue;

            return true;
        }
        else
        {
            Debug.LogError("Invalid dialogue name: " + dialogue);

            return false;
        }
    }

    private bool SetCrowDialogue(string dialogue)
    {
        if (Enum.TryParse<EDialogueType>(dialogue, out EDialogueType crowDialogue))
        {
            InGameData.Instance.CrowDialogue = crowDialogue;

            return true;
        }
        else
        {
            Debug.LogError("Invalid dialogue name: " + dialogue);

            return false;
        }
    }

    private bool SetActiveMinigame1_Button(bool b)
    {
        InGameData.Instance.miniGame1_ButtonShouldBeActive = b;

        return true;
    }

    private bool SetActiveVenus_Button(bool b)
    {
        InGameData.Instance.venus_ButtonShouldBeActive = b;

        return true;
    }

    private bool SetDialogueBasedOnPartner()
    {
        variableStorage.SetValue("$Win_1", InGameData.Instance.continueWithPartner);
        return true;
    }

    private bool IntroCutsceneSetup(int key)
    {
        IntroCutsceneManager introCutsceneManager = GetComponent<IntroCutsceneManager>();
        return introCutsceneManager.CallIntroCutsceneSetupFunction(key);
    }

    private bool SetActiveConclusionWidgetIndex(int index)
    {
        InGameData.Instance.conclusionWidgetIndex = index;
        return true;
    }

    private bool SetNonRomanceableOutcome(int outcome)
    {
        switch (InGameData.Instance.DialogueType)
        {
            case EDialogueType.Venus_101:
                InGameData.Instance.nonRomanceableOutcomes[ECharacterType.NRCharacter1] = outcome;
                break;
        }
        return true;
    }

    public bool ModifyReputation(int value)
    {
        int intReputation = System.Convert.ToInt32(reputation);

        intReputation += value;
        reputation = intReputation;

        switch (InGameData.Instance.DialogueType)
        {
            case EDialogueType.Hero_101:
                variableStorage.SetValue("$HeroLove", intReputation);
                break;
            case EDialogueType.Crow_101:
                variableStorage.SetValue("$CrowLove", intReputation);
                break;
        }

        ChangeSliderValue();

        return true;
    }
}

//Custom inspector GUI
#if UNITY_EDITOR
#region
[CustomEditor(typeof(DialogueFunctionality))]
public class CutSceneDebugging : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        DialogueFunctionality dialogueFunctionality = (DialogueFunctionality)target;
        int intReputation = System.Convert.ToInt32(dialogueFunctionality.reputation);

        GUILayout.Space(20);
        GUILayout.Label($"\nYou need to press \"Debug Mode\" to make changes for \"reputation\" variable in the inspector", GUI.skin.window);

        if (GUILayout.Button("Debug Mode"))
        {
            dialogueFunctionality.debugMode = !dialogueFunctionality.debugMode;
        }

        if (dialogueFunctionality.debugMode == true)
        {
            if (GUILayout.Button("Increase reputation by 5"))
            {
                if (intReputation + 5 >= 100) intReputation = 100;
                else
                {
                    dialogueFunctionality.ModifyReputation(5);
                    intReputation += 5;
                }
            }

            if (GUILayout.Button("Decrease reputation by 5"))
            {
                if (intReputation - 5 < 0) intReputation = 0;
                else
                {
                    dialogueFunctionality.ModifyReputation(5);
                    intReputation -= 5;
                }
            }

            EditorGUI.BeginDisabledGroup(true);
            EditorGUILayout.LabelField("Reputation", dialogueFunctionality.reputation.ToString() ?? default);
            EditorGUI.EndDisabledGroup();
            GUILayout.Space(20);
        }

        dialogueFunctionality.reputation = intReputation;
    }
}
public class ReadOnlyAttribute : PropertyAttribute { }

[CustomPropertyDrawer(typeof(ReadOnlyAttribute))]
public class ReadOnlyDrawer : PropertyDrawer
{
    public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
    {
        return EditorGUI.GetPropertyHeight(property, label, true);
    }

    public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
    {
        GUI.enabled = false;
        EditorGUI.PropertyField(position, property, label, true);
        GUI.enabled = true;
    }
}
#endregion
#endif
