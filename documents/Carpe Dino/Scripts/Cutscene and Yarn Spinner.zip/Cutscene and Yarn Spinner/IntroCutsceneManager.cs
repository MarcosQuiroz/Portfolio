using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Events;

public class IntroCutsceneManager : MonoBehaviour
{
    [SerializeField] GameObject dialogueBox;
    [SerializeField] GameObject mapClouds;

    [SerializeField] GameObject mapBackground;
    [SerializeField] GameObject waterBackground;
    [SerializeField] GameObject reflectionBackground;
    [SerializeField] GameObject twoDinosBackground;
    [SerializeField] GameObject regularBackground;

    private Dictionary<int, UnityAction> setupFunctions = new Dictionary<int, UnityAction>();

    private void Awake()
    {
        setupFunctions.Add(1, SetupWaterBackground);
        setupFunctions.Add(2, SetupReflectionBackground);
        setupFunctions.Add(3, SetupTwoDinosBackground);
        setupFunctions.Add(4, SetupAnkyBackground);
    }

    public bool CallIntroCutsceneSetupFunction(int key)
    {
        if (setupFunctions.ContainsKey(key))
        {
            setupFunctions[key].Invoke();
            return true;
        }
        else
        {
            Debug.LogError("No setup function found for SetupType: " + key);
            return false;
        }
    }

    void SetupWaterBackground()
    {
        mapBackground.SetActive(false);
        mapClouds.SetActive(false);
        waterBackground.SetActive(true);
    }

    void SetupReflectionBackground()
    {
        waterBackground.SetActive(false);
        reflectionBackground.SetActive(true);
    }

    void SetupTwoDinosBackground()
    {
        regularBackground.SetActive(false);
        reflectionBackground.SetActive(false);
        twoDinosBackground.SetActive(true);

        for(int i = 0; i < 3; i++)
        {
            RectTransform rectTransform = dialogueBox.transform.GetChild(i).GetComponent<RectTransform>();

            rectTransform.anchoredPosition = new Vector2(231, rectTransform.anchoredPosition.y);
        }


        GetComponent<CutSceneManager>().GetDinoExpressionsObject().SetActive(false);
    }

    void SetupAnkyBackground()
    {
        reflectionBackground.SetActive(false);
        twoDinosBackground.SetActive(false);
        regularBackground.SetActive(true);

        for (int i = 0; i < 3; i++)
        {
            RectTransform rectTransform = dialogueBox.transform.GetChild(i).GetComponent<RectTransform>();

            rectTransform.anchoredPosition = new Vector2(231, rectTransform.anchoredPosition.y);
        }

        GetComponent<CutSceneManager>().GetDinoExpressionsObject().SetActive(true);
    }
}
