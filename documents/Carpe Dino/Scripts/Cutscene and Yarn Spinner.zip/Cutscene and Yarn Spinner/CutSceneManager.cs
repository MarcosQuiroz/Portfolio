using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Yarn.Unity;
using Yarn;
using System.ComponentModel;
using JetBrains.Annotations;
using System.IO;


public class CutSceneManager : MonoBehaviour
{
    [SerializeField] private Yarn.Unity.DialogueRunner dialogueRunner;
    [SerializeField] private Yarn.Unity.LineView lineView;
    [SerializeField] private GameObject dinoExpressionUI;
    [SerializeField] private Image cutsceneImage;
    [SerializeField] private Sprite[] cutsceneBackgrounds;

    UIOnClickedActions onClickActions;

    private void Start()
    {
        onClickActions = FindObjectOfType<UIOnClickedActions>();
        lineView = FindObjectOfType<LineView>();

        LoadCutscene();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            onClickActions.TogglePauseSettingPanel();
        }

        if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(KeyCode.KeypadEnter))
        {
            lineView.UserRequestedViewAdvancement();
        }
    }

    public void LoadCutscene()
    {
        switch (InGameData.Instance.DialogueType)
        {
            case EDialogueType.Map_101:
                dinoExpressionUI.SetActive(false);
                break;
            case EDialogueType.Crow_101:
                dinoExpressionUI.SetActive(true);
                SoundManager.Instance.PlayBackgroundMusic("Ambience_Jungle_01");
                cutsceneImage.sprite = cutsceneBackgrounds[1];
                break;
            case EDialogueType.Crow_102:
                dinoExpressionUI.SetActive(true);
                SoundManager.Instance.PlayBackgroundMusic("Ambience_Jungle_01");
                cutsceneImage.sprite = cutsceneBackgrounds[1];
                break;
            case EDialogueType.Hero_101:
                dinoExpressionUI.SetActive(true);
                SoundManager.Instance.PlayBackgroundMusic("Ambience_Jungle_01");
                cutsceneImage.sprite = cutsceneBackgrounds[2];
                break;
            case EDialogueType.Hero_102:
                dinoExpressionUI.SetActive(true);
                SoundManager.Instance.PlayBackgroundMusic("Ambience_Jungle_01");
                cutsceneImage.sprite = cutsceneBackgrounds[2];
                break;
            case EDialogueType.Venus_101:
                dinoExpressionUI.SetActive(false);
                SoundManager.Instance.PlayBackgroundMusic("Ambience_Jungle_01");
                cutsceneImage.sprite = cutsceneBackgrounds[3];
                break;
            case EDialogueType.Asteroid_1:
                dinoExpressionUI.SetActive(true);
                SoundManager.Instance.PlayBackgroundMusic("Ambience_Jungle_01");
                cutsceneImage.sprite = cutsceneBackgrounds[0];
                break;
            case EDialogueType.Crow_200:
                dinoExpressionUI.SetActive(true);
                cutsceneImage.sprite = cutsceneBackgrounds[1];
                break;
            case EDialogueType.Hero_200:
                dinoExpressionUI.SetActive(true);
                cutsceneImage.sprite = cutsceneBackgrounds[2];
                break;
        }

        if (dialogueRunner.IsDialogueRunning)
            dialogueRunner.Stop();

        dialogueRunner.StartDialogue(InGameData.Instance.DialogueType.ToString());
    }

    public GameObject GetDinoExpressionsObject()
    { return dinoExpressionUI; }
}