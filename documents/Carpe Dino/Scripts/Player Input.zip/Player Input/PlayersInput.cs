using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayersInput : MonoBehaviour
{
    [SerializeField] bool ActivatePlayerHorizontalController;
    [SerializeField] bool ActivateBuddyHorizontalController;
    [SerializeField] bool BuddyIsAuto = true;

    private MiniGamesInput gameInput;

    public float horizontalPlayerInput { get; set; } = 0;
    public float verticalPlayerInput { get; set; } = 0;
    public float horizontalBuddyInput { get; set; } = 0;
    public float verticalBuddyInput { get; set; } = 0;

    public Vector2 movementController { get; private set; } = Vector2.zero;

    public bool isGamePaused { get;  set; } = false;
    public bool buddyShieldDisabled { get; set; } = false;
    public bool abilityDisabled { get; set; } = false;

    private PartnerCharacter partner;
    private PlayerBehavior player;
    private PartnerController partnerController;
    bool buddyIsUsingShield = false;

    private void Awake()
    {
        gameInput = new MiniGamesInput();
    }

    private void Start()
    {
        player = FindObjectOfType<PlayerBehavior>();
        partner = FindObjectOfType<PartnerCharacter>();
        partnerController = FindObjectOfType<PartnerController>();   
    }

    private void OnEnable()
    {
        gameInput.Enable();

        // Movement
        gameInput.Players.WASDVertical.performed += VerticalPlayerInput;

        if (ActivatePlayerHorizontalController)
            gameInput.Players.WASDHorizontal.performed += HorizontalPlayerInput;

        if (!BuddyIsAuto)
        {
            gameInput.Players.ArrowsVertical.performed += VerticalBuddyInput;

            if (ActivateBuddyHorizontalController)
                gameInput.Players.ArrowsHorizontal.performed += HorizontalBuddyInput;
        }

        //Ability
        gameInput.Players.Ability.started += UseAbility;

        // Shield
        gameInput.Players.BuddyShield.started += BuddyShield;

        // Pause
        gameInput.Players.Pause.started += Pause;

        // Controller
        gameInput.Players.PlayerMovementController.performed += PlayerControllerInput;
        gameInput.Players.PartnerMovementController.performed += PartnerControllerInput;
    }

    private void OnDisable()
    {
        gameInput.Disable();

        // Movement
        gameInput.Players.WASDVertical.performed -= VerticalPlayerInput;

        if (ActivatePlayerHorizontalController)
            gameInput.Players.WASDHorizontal.performed -= HorizontalPlayerInput;

        if (!BuddyIsAuto)
        {
            gameInput.Players.ArrowsVertical.performed -= VerticalBuddyInput;

            if (ActivateBuddyHorizontalController)
                gameInput.Players.ArrowsHorizontal.performed -= HorizontalBuddyInput;
        }

        //Ability
        gameInput.Players.Ability.started -= UseAbility;

        // Shield
        gameInput.Players.BuddyShield.started -= BuddyShield;

        // Pause
        gameInput.Players.Pause.started -= Pause;

        // Controller
        gameInput.Players.PlayerMovementController.performed -= PlayerControllerInput;
        gameInput.Players.PartnerMovementController.performed -= PartnerControllerInput;
    }

    private void HorizontalPlayerInput(InputAction.CallbackContext context)
    {
        float inputValue = context.ReadValue<float>();

        if (!player.playerWasHit)
            horizontalPlayerInput = inputValue;
        else 
            horizontalPlayerInput = 0;
    }

    private void VerticalPlayerInput(InputAction.CallbackContext context)
    {
        float inputValue = context.ReadValue<float>();

        if (!player.playerWasHit)
            verticalPlayerInput = inputValue;
        else
            verticalPlayerInput = 0;
    }

    private void HorizontalBuddyInput(InputAction.CallbackContext context)
    {
        float inputValue = context.ReadValue<float>();

        if (!partner.partnerWasHit)
            horizontalBuddyInput = inputValue;
        else
            horizontalBuddyInput = 0;
    }

    private void VerticalBuddyInput(InputAction.CallbackContext context)
    {
        float inputValue = context.ReadValue<float>();

        if (!partner.partnerWasHit)
            verticalBuddyInput = inputValue;
        else
            verticalBuddyInput = 0;
    }

    private void BuddyShield(InputAction.CallbackContext context)
    {
        if (buddyShieldDisabled) return;
        buddyIsUsingShield = !buddyIsUsingShield;

        if (partnerController.GetShield() != null)
            partnerController.GetShield().SetActive(buddyIsUsingShield);
    }

    private void UseAbility(InputAction.CallbackContext context)
    {
        if (abilityDisabled) return;
        partner.UseAbility();
    }

    public bool GetPlayerHorizontalController() { return ActivatePlayerHorizontalController; }
    public bool GetBuddyHorizontalController() { return ActivateBuddyHorizontalController; }

    public bool GetIsBuddyAuto() { return BuddyIsAuto; }

    private void Pause(InputAction.CallbackContext context)
    {
        UIOnClickedActions clickedActions = FindObjectOfType<UIOnClickedActions>();
        clickedActions.TogglePause();
    }

    private void PlayerControllerInput(InputAction.CallbackContext context)
    {
        Vector2 inputValue = context.ReadValue<Vector2>();
        verticalPlayerInput = inputValue.y;

        if (ActivatePlayerHorizontalController)
        {
            horizontalPlayerInput = inputValue.x;
        }
    }

    private void PartnerControllerInput(InputAction.CallbackContext context)
    {
        Vector2 inputValue = context.ReadValue<Vector2>();
        verticalBuddyInput = inputValue.y;

        if (ActivateBuddyHorizontalController)
        {
            horizontalBuddyInput = inputValue.x;
        }
    }

    public void PlayHaptics(float seconds, float lowFrecuency, float highFrecuency)
    {
        StartCoroutine(PlayHapticsRoutine(seconds, lowFrecuency, highFrecuency));
    }

    private IEnumerator PlayHapticsRoutine(float seconds, float lowFrecuency, float highFrecuency)
    {
        Gamepad.current.SetMotorSpeeds(lowFrecuency, highFrecuency);
        yield return new WaitForSeconds(seconds);

        InputSystem.ResetHaptics();
    }

    public bool GetBuddyIsUsingShield() { return buddyIsUsingShield; }
}
