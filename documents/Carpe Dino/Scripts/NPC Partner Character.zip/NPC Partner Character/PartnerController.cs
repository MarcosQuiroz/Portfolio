using NavMeshPlus.Components;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Windows;
using static UnityEngine.Rendering.DebugUI;

public class PartnerController : MonoBehaviour
{
    [SerializeField] float checkRadius = 2.0f;
    [SerializeField] LayerMask dangerLayerMask;
    [SerializeField] public Animator hitAnimator;
    [SerializeField] float randomMovementIntervalTime = 3f;

    private float nextCheckTime = 0f;
    NavMeshAgent agent;

    DangerSpawnerManager dangerSpawner;
    PlayersInput input;
    List<Danger> targetableDangers = new List<Danger>();
    List<Transform> avoidableDangers = new List<Transform>();
    GameObject shield;

    Vector2 topLeftPosition;
    Vector2 bottomRightPosition;

    bool isMovingAway = false;
    bool isMovingToIntercept = false;
    public bool isDead { get; set; } = false;
    Vector3 deathDirection = new Vector3(0, -1, 0);

    private void Start()
    {
        dangerSpawner = GameObject.Find("DangerSpawnerManagerPlayer").GetComponent<DangerSpawnerManager>();
        shield = transform.GetChild(0).gameObject;

        nextCheckTime = Time.time + randomMovementIntervalTime;

        input = FindObjectOfType<PlayersInput>();

        agent = GetComponent<NavMeshAgent>();
        agent.updateRotation = false;
        agent.updateUpAxis = false;

        NavMeshSurface surface = FindObjectOfType<NavMeshSurface>();
        surface.BuildNavMesh();

        NavMeshData navMeshData = surface.navMeshData;

        float TopX = (navMeshData.sourceBounds.center.x - (navMeshData.sourceBounds.extents.x - 1));
        float TopY = (navMeshData.sourceBounds.center.z + (navMeshData.sourceBounds.extents.z - 1));

        float BottomX = (navMeshData.sourceBounds.center.x + (navMeshData.sourceBounds.extents.x - 1));
        float BottomY = (navMeshData.sourceBounds.center.z - (navMeshData.sourceBounds.extents.z - 1));

        topLeftPosition = new Vector2(TopX, TopY);
        bottomRightPosition = new Vector2(BottomX, BottomY);
    }
    void Update()
    {
        if (isDead)
        {
            agent.enabled = false;
            transform.position += (deathDirection * 2 * Time.deltaTime);
            return;
        }

        GetTargetableDangers();

        if(agent.velocity.magnitude == 0)
        {
            isMovingToIntercept = false;
            isMovingAway = false;
        }

        if (targetableDangers.Count() > 0)
            MoveToInterceptEnemy();
        else
            MoveToRandomPosition();

        targetableDangers.Clear();
        avoidableDangers.Clear();
    }

    bool CheckForNearbyAvoidableDangers()
    {
        Collider2D[] colliders = Physics2D.OverlapCircleAll((Vector2)transform.position, checkRadius, dangerLayerMask.value);

        foreach (Collider2D collider in colliders)
            avoidableDangers.Add(collider.gameObject.transform);
        
        if (colliders.Count() > 0)
            return true;

        return false;
    }

    public void GetTargetableDangers()
    {
        foreach (Transform d in dangerSpawner.transform)
        {
            Danger danger = d.GetComponent<Danger>();

            if (d.gameObject.activeSelf && danger != null && danger.dangerType == Danger.EDangerType.Targetable)
            {
                targetableDangers.Add(danger);
            }
        }
    }

    private void MoveToRandomPosition()
    {
        if (isMovingAway)
            return;

        bool foundAvoidableDangers = CheckForNearbyAvoidableDangers();

        if (Time.time > nextCheckTime || foundAvoidableDangers)
        {
            nextCheckTime = Time.time + randomMovementIntervalTime;
            
            Vector3 targetLocation = FindValidPosition();

            if (!input.GetBuddyHorizontalController()) // Only move vertically
                targetLocation = new Vector3(transform.position.x, targetLocation.y, 0);

            while (!agent.SetDestination(targetLocation)) { }
                
            isMovingAway = true;
        }
    }

    private void MoveToInterceptEnemy()
    {
        if (isMovingToIntercept)
            return;

        Vector3 targetLocation = Vector3.zero;
        Danger closestDanger = FindClosestTargetableDanger();

        if (input.GetBuddyHorizontalController()) // Move any direction
        {
            // Use the initial position and direction of the closest danger
            Vector2 initialPosition = closestDanger.transform.position;
            Vector2 direction = closestDanger.direction;

            // Calculate the projection of the buddy's position onto the trajectory

            Vector2 buddyPosition = transform.position;
            Vector2 trajectoryToPoint = Vector2.Dot(buddyPosition - initialPosition, direction) * direction;
            targetLocation = initialPosition + trajectoryToPoint;
        }
        else // Only move vertically
        {
            // Use the initial position and direction of the closest danger
            Vector2 initialPosition = closestDanger.transform.position;
            Vector2 direction = closestDanger.direction;

            // Calculate the intersection point of the trajectory with the vertical line at the buddy's position
            targetLocation = CalculateIntersectionPoint(initialPosition, direction, transform.position.x);
        }

        nextCheckTime = Time.time + randomMovementIntervalTime;
        agent.SetDestination(targetLocation);
        isMovingToIntercept = true;
    }

    Danger FindClosestTargetableDanger()
    {
        Danger closest = null;
        float closestDistance = float.MaxValue;
        Vector2 currentPosition = transform.position;

        foreach (Danger dangerObject in targetableDangers)
        {
            float distance = Vector2.Distance(currentPosition, dangerObject.transform.position);

            if (distance < closestDistance)
            {
                closest = dangerObject;
                closestDistance = distance;
            }
        }

        return closest;
    }

    Vector2 CalculateIntersectionPoint(Vector2 start, Vector2 direction, float verticalLineX)
    {
        // Calculate the intersection point of the trajectory with the vertical line
        float t = (verticalLineX - start.x) / direction.x;
        return start + t * direction;
    }

    // It is being called with a animation event
    void ShieldAnimTrigger()
    {
        Vector3 tailPosition = new Vector3(2.25f, 1.25f, 0);

        hitAnimator.transform.localPosition = tailPosition;
        hitAnimator.SetTrigger("ShieldHit");
    }

    public void UpdateAnimationPosition(Vector3 position)
    {
        hitAnimator.transform.position = position;
    }

    public GameObject GetShield() { return shield; }

    Vector2 FindValidPosition()
    {
        Vector2 position;
        bool validPosition;

        do
        {
            position = new Vector2(Random.Range(topLeftPosition.x, bottomRightPosition.x), Random.Range(topLeftPosition.y, bottomRightPosition.y));
            validPosition = true;

            foreach (Transform obj in avoidableDangers)
            {
                if (Vector2.Distance(position, obj.position) < 3)
                {
                    validPosition = false;
                    break;
                }
            }
        } while (!validPosition);

        return position;
    }
}