using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Windows;

public abstract class PartnerCharacter : MonoBehaviour
{
    [SerializeField]
    protected float abilityAnimationDuration = 1.0f;
    [SerializeField]
    protected float abilityCycleDuration = 0.35f;
    protected bool abilityAnimationActive = false;
    protected CharacterEnergy characterEnergy;
    GameObject partnerDeathCanvas;
    float timer = 0;
    public bool partnerIsDead { get; private set; } = false;
    public Animator partnerAnimator { get; private set; }
    public bool partnerWasHit {  get; set; }

    public int damage { get; set; } = 10;

    [HideInInspector] public EnergyBarFlickeringManager partnerBarFlickeringManager;

    protected virtual void Start()
    {
        partnerAnimator = GetComponent<Animator>();
        characterEnergy = GetComponent<CharacterEnergy>();
        characterEnergy.energyManager.onEnergyDepleted.AddListener(OnPartnerDeath);

        partnerDeathCanvas = GameObject.Find("[UI]").transform.GetChild(2).gameObject;

        partnerBarFlickeringManager = FindFirstObjectByType<EnergyBarFlickeringManager>();
    }

    protected virtual void Update()
    {
        if (gameObject.transform.position.y < -6)
            gameObject.SetActive(false);

        if (abilityAnimationActive) PlayAbilityAnimation();
    }

    void OnPartnerDeath()
    {
        characterEnergy.energyManager.onEnergyDepleted.RemoveListener(OnPartnerDeath);

        PartnerShield shield = transform.GetChild(0).GetComponent<PartnerShield>();

        if(shield != null)
            Destroy(shield.gameObject);

        Time.timeScale = 0;
        partnerIsDead = true;
        partnerDeathCanvas.SetActive(true);
    }
    public abstract void UseAbility();

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("ScreenBorder") && partnerIsDead)
        {
            gameObject.SetActive(false);
        }
    }

    public void HitAnimationfinished()
    {
        partnerWasHit = false;
    }

    public CharacterEnergy GetCharacterEnergy()
    {
        return characterEnergy;
    }

    protected void PlayAbilityAnimation()
    {
        if (timer == 0)
        {
            partnerAnimator.SetTrigger("Ability");
        }

        timer += Time.deltaTime;
        if (timer >= abilityCycleDuration) timer = 0;
    }

    protected IEnumerator StartAbilityAnimation()
    {
        abilityAnimationActive = true;
        yield return new WaitForSeconds(abilityAnimationDuration);
        abilityAnimationActive = false;
    }
}
