using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;

public class Oska : PartnerCharacter
{
    [SerializeField] float timerInSeconds = 3;

    PlayerBehavior playerBehavior;

    RectTransform keyboardTransform;
    GameObject keyboard;
    Image keyboardImage;
    Image keyWImage;
    Image keySImage;
    Image keyAImage;
    Image keyDImage;

    bool shortcutWasUsed = false;
    bool shortcutWasTaken = false;

    Color correctKeyPressedColor = new Color(0.643f, 0.890f, 0.482f);
    Color incorrectKeyPressedColor = new Color(0.89f, 0.482f, 0.482f);

    List<string> keys = new List<string>();
    LinkedList<int> keysIndex = new LinkedList<int>();

    LinkedList<int> keysIndexControl = new LinkedList<int>();

    protected override void Start()
    {
        base.Start();

        keyboard = GameObject.Find("Keyboard");
        keyboardTransform = keyboard.GetComponent<RectTransform>();

        keyboardImage = keyboard.GetComponent<Image>();
        keyWImage = keyboard.transform.GetChild(0).GetComponent<Image>();
        keySImage = keyboard.transform.GetChild(1).GetComponent<Image>();
        keyAImage = keyboard.transform.GetChild(2).GetComponent<Image>();
        keyDImage = keyboard.transform.GetChild(3).GetComponent<Image>();

        playerBehavior = FindObjectOfType<PlayerBehavior>();
    }

    private void Update()
    {
        if (!keyboardImage.enabled)
            return;

        keyboardTransform.anchoredPosition = GetScreenPosition();


        if (Input.GetKeyDown(KeyCode.W))
        {
            if(keysIndexControl.Last.Value == 0)
            {
                keyWImage.color = correctKeyPressedColor;
                keyWImage.enabled = true;
                keysIndexControl.RemoveLast();
            }
            else
            {
                keyWImage.color = incorrectKeyPressedColor;
                keyWImage.enabled = true;
                keysIndexControl = keysIndex;
            }

            StartCoroutine(DisableKey(keyWImage));
        }
        else if (Input.GetKeyDown(KeyCode.S))
        {
            if (keysIndexControl.Last.Value == 1)
            {
                keySImage.color = correctKeyPressedColor;
                keySImage.enabled = true;
                keysIndexControl.RemoveLast();
            }
            else
            {
                keySImage.color = incorrectKeyPressedColor;
                keySImage.enabled = true;
                keysIndexControl = keysIndex;
            }

            StartCoroutine(DisableKey(keySImage));
        }
        else if (Input.GetKeyDown(KeyCode.A))
        {
            if (keysIndexControl.Last.Value == 2)
            {
                keyAImage.color = correctKeyPressedColor;
                keyAImage.enabled = true;
                keysIndexControl.RemoveLast();
            }
            else
            {
                keyAImage.color = incorrectKeyPressedColor;
                keyAImage.enabled = true;
                keysIndexControl = keysIndex;
            }

            StartCoroutine(DisableKey(keyAImage));
        }
        else if (Input.GetKeyDown(KeyCode.D))
        {
            if (keysIndexControl.Last.Value == 3)
            {
                keyDImage.color = correctKeyPressedColor;
                keyDImage.enabled = true;
                keysIndexControl.RemoveLast();
            }
            else
            {
                keyDImage.color = incorrectKeyPressedColor;
                keyDImage.enabled = true;
                keysIndexControl = keysIndex;
            }

            StartCoroutine(DisableKey(keyDImage));
        }
    }

    public override void UseAbility()
    {
        if (!shortcutWasUsed && UIAbilitiesManager.instance.GetCurrentAbilities() > 0)
        {
            shortcutWasUsed = true;
            keyboardImage.enabled = true;

            int index1 = Random.Range(0, 4);
            int index2 = Random.Range(0, 4);
            int index3 = Random.Range(0, 4);

            keysIndex.AddLast(index3);
            keysIndex.AddLast(index2);
            keysIndex.AddLast(index1);

            keysIndexControl = keysIndex;

            string codeText = CreateOrderOfExecutionForBark(index1, index2, index3);

            BarksManager barksManager = FindObjectOfType<BarksManager>();
            barksManager.AddOrderOfExecutionToOskaAbilityBark(codeText);
            StartCoroutine(barksManager.PlayAbilityBark());

            StartCoroutine(StartAbilityTimer());
        }
    }

    IEnumerator StartAbilityTimer()
    {
        float controlTime = 0;

        while(controlTime < timerInSeconds)
        {
            controlTime += Time.deltaTime;

            if (keysIndexControl.Count == 0)
            {
                Debug.Log("Shortcut was taken successfully!");
                shortcutWasTaken = true;
                break;
            }

            yield return null;
        }

        StartCoroutine(DisableKey(keyboardImage));
    }

    Vector2 GetScreenPosition()
    {
        Vector3 Pos = new Vector3(playerBehavior.transform.position.x, playerBehavior.transform.position.y + 1, 0);
        Canvas canvas = keyboardImage.transform.parent.GetComponentInParent<Canvas>();
        Vector3 screenPos = Camera.main.WorldToScreenPoint(Pos);
        RectTransformUtility.ScreenPointToLocalPointInRectangle(canvas.transform as RectTransform, screenPos, canvas.worldCamera, out Vector2 anchoredPosition);

        return anchoredPosition;
    }

    string CreateOrderOfExecutionForBark(int index1, int index2, int index3)
    {
        string codeText = string.Empty;

        switch(index1)
        {
            case 0:
                codeText += "W + ";
                break;
            case 1:
                codeText += "S + ";
                break;
            case 2:
                codeText += "A + ";
                break;
            case 3:
                codeText += "D + ";
                break;
        }

        switch (index2)
        {
            case 0:
                codeText += "W + ";
                break;
            case 1:
                codeText += "S + ";
                break;
            case 2:
                codeText += "A + ";
                break;
            case 3:
                codeText += "D + ";
                break;
        }

        switch (index3)
        {
            case 0:
                codeText += "W";
                break;
            case 1:
                codeText += "S";
                break;
            case 2:
                codeText += "A";
                break;
            case 3:
                codeText += "D";
                break;
        }

        return codeText;
    }

    IEnumerator DisableKey(Image key)
    {
        yield return new WaitForSeconds(0.2f);
        key.enabled = false;
    }
}
