using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DangerPool : MonoBehaviour
{
    GameObject dangerPrefab;
    GameObject parentGameObject;
    Queue<GameObject> dangerPool = new Queue<GameObject>();

    public void BuildBulletPool(int poolSize, GameObject dangerPrefab, GameObject parentGameObject)
    {
        this.dangerPrefab = dangerPrefab;
        this.parentGameObject = parentGameObject;

        for (int i = 0; i < poolSize; i++)
        {
            CreateDanger();
        }
    }

    void CreateDanger()
    {
        GameObject danger = Instantiate(dangerPrefab);
        danger.GetComponent<Danger>().pool = this;

        danger.SetActive(false);
        danger.transform.SetParent(parentGameObject.transform);
        dangerPool.Enqueue(danger);
    }

    public GameObject GetDanger(Vector3 spawnPos)
    {
        if (dangerPool.Count < 1)
            CreateDanger();

        GameObject danger = dangerPool.Dequeue();
        danger.SetActive(true);
        danger.transform.position = spawnPos;      



        return danger;
    }

    public void ReturnDanger(GameObject danger)
    {
        danger.SetActive(false);
        dangerPool.Enqueue(danger);
    }

    public Danger getDangerPrefab()
    {
        Danger danger = dangerPrefab.GetComponent<Danger>();

        if (danger == null)
        {
            Debug.Log("Danger prefab is not a danger!");
            return null;
        }

        return danger;
    }
}
