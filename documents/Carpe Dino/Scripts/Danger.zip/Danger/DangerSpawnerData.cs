using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public struct DangerSpawnerData
{
    public GameObject DangerPrefab;
    public int PoolSize;
    public int initialDelay;
    public List<IntervalsOfSpawningData> IntervalsInteractions;
}

[System.Serializable]
public struct IntervalsOfSpawningData
{
    public int timeToUpdateSpawnIntervals;
    public float MinSpawnInterval;
    public float MaxSpawnInterval;
}