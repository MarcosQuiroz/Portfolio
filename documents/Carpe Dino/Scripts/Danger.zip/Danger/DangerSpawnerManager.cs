using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Unity.VisualScripting;
using UnityEngine;

public class DangerSpawnerManager : MonoBehaviour
{
    [SerializeField] List<DangerSpawnerData> dangerSpawnerData;
    [SerializeField] GameObject player;
    [SerializeField] bool isPlayerTheTarget = true;
    [SerializeField] public bool SpawnerPause= false;


    GameObject partner;
    Newt hero;
    List<DangerPool> poolList = new List<DangerPool>();

    protected Timer timer;

    void Start()
    {
        partner = FindObjectOfType<PartnerController>().gameObject;
        hero = FindObjectOfType<Newt>();
        timer = FindObjectOfType<Timer>();

        foreach (DangerSpawnerData danger in dangerSpawnerData)
        {
            DangerPool pool = new DangerPool();
            pool.BuildBulletPool(danger.PoolSize, danger.DangerPrefab, gameObject);
            poolList.Add(pool);

            if(isPlayerTheTarget)
                StartCoroutine(SpawnRepeatedly(danger, pool, player));
            else
                StartCoroutine(SpawnRepeatedly(danger, pool, partner));
        }
    }


    IEnumerator SpawnRepeatedly(DangerSpawnerData spawnerData, DangerPool pool, GameObject targetGO)
    {
        int spawnIntervalIndex = 0;

        yield return new WaitForSeconds(spawnerData.initialDelay);

        while (true)
        {
            if (spawnIntervalIndex < spawnerData.IntervalsInteractions.Count)
            {
                if (spawnIntervalIndex != 0 && timer.initialTime - timer.GetRemainingTime() >= spawnerData.IntervalsInteractions[spawnIntervalIndex].timeToUpdateSpawnIntervals)
                {
                    spawnIntervalIndex++;
                }
            }

            while (SpawnerPause)
            {
                yield return null;
            }

            SpawnDanger(pool, targetGO);
            float randomInterval = Random.Range(spawnerData.IntervalsInteractions[spawnIntervalIndex].MinSpawnInterval, spawnerData.IntervalsInteractions[spawnIntervalIndex].MaxSpawnInterval);

            yield return new WaitForSeconds(randomInterval);
        }
    }

    void SpawnDanger(DangerPool pool, GameObject targetGO)
    {
        float xPos = transform.position.x;
        GameObject danger = null;
        Danger dangerPrefab = pool.getDangerPrefab();

        if (dangerPrefab is Obstacle)
        {
            Vector3 spawnPosition = new Vector3(Random.Range(-3.0f, 3.0f), 5.5f, 0f);
            danger = pool.GetDanger(spawnPosition);
        }
        else
        {
            Vector3 spawnPos = new Vector3(xPos, Random.Range(-4.0f, 4.0f), 0);
            danger = pool.GetDanger(spawnPos);
        }

        if (targetGO == partner && partner.GetComponent<PartnerController>().isActiveAndEnabled)
        {
            if (!partner.GetComponent<PartnerController>().isDead)
                danger.GetComponent<Danger>().Target = targetGO;
            else
                danger.GetComponent<Danger>().Target = player;
        }
        else
        {
            danger.GetComponent<Danger>().Target = player;
        }

        danger.GetComponent<Danger>().InitializeDanger();
    }

    public void DeactivePartner()
    {
        partner.GetComponent<PartnerController>().isDead = true;
    }

    public List<DangerPool> GetPoolList() { return poolList; }
    public DangerSpawnerData GetFirstSpawnerData() { return dangerSpawnerData[0]; }

    public bool GetIsPlayerTheTarget() { return isPlayerTheTarget; }
    public GameObject GetPlayer() { return player; }
    public GameObject GetPartner() { return partner; }
}
